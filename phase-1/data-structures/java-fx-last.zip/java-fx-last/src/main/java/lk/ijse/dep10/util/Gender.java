package lk.ijse.dep10.util;

public enum Gender {
    MALE,FEMALE
}
